package com.example.tipcalculatorv3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.NumberFormat;

// in version 2 we add colors, center items
// version 3 begins adding calculations

public class MainActivity extends AppCompatActivity {

    private final TipCalculator tipCalc;
    private final NumberFormat money = NumberFormat.getNumberInstance();

    public MainActivity(TipCalculator tipCalc) {
        this.tipCalc = tipCalc;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate (View v) {

        Log.w("MainActivity", "v = " + v);

        EditText billEditText = findViewById(R.id.et_bill_amt);
        EditText tipEditText = findViewById(R.id.et_tip_amt);

        String billString = billEditText.getText().toString();
        String tipString = tipEditText.getText().toString();

        TextView tipTextView = findViewById(R.id.tv_tip_pct);
        TextView totalTextView = findViewById(R.id.tv_bill);

        try {

            float billAmount = Float.parseFloat(billString);
            int tipPercent = Integer.parseInt(tipString);

            tipCalc.setBill(billAmount);
            tipCalc.setTip(.01f * tipPercent);

            float tip = tipCalc.tipAmount();
            float total = tipCalc.totalAmount();

            tipTextView.setText(money.format(tip));
            totalTextView.setText(money.format(total));

        }catch (NumberFormatException nfe) {
            nfe.printStackTrace();
        }
        }


}



